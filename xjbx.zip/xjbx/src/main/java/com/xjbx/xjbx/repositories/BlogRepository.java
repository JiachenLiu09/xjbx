package com.xjbx.xjbx.repositories;

import com.xjbx.xjbx.enitites.Blog;
import org.springframework.data.repository.CrudRepository;

public interface BlogRepository extends CrudRepository<Blog,Integer> {
}
